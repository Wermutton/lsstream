# Add more templates if necessary. 
# Select the one you want in the import of file_generation.py

TEMPLATE_1 = '<p><a href="{LINK}">Click for {TITLE}</a></p>'
